package com.web.book.version.model;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}