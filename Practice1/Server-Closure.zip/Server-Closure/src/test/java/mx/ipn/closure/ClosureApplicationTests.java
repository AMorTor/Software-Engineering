package mx.ipn.closure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClosureApplicationTests {

    @Test
    void contextLoads() {
    }

}
